<?php

namespace App\SupportedApps\Headphones;

class Headphones extends \App\SupportedApps
{
}
