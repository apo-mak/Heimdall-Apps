<ul class="livestats">
    <li>
        <img style="margin: 0 2px 2px; width:20px; height:20px; border:none;"
            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABUAAAAVCAIAAAAmdTLBAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAFZJREFUeNpi/P//PwMFgBGo/7KUGnmadZ/dYmKgDFCqnwVTSKI1CMJ4Ub0Olwg+/wN9BWHAxTFFBo3/B2H4v55fQVBk0KS/oZ5+hnr4U6qfkcLyDyDAAK8eRB+e6G+qAAAAAElFTkSuQmCC">
        <p style="margin:0 auto; font-size:12px; font-weight:bold;">{!! $alarms !!}</p>
    </li>
    <li>
        <img style="margin: 0 2px 2px; width:20px; height:20px; border:none;"
            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABUAAAAVCAIAAAAmdTLBAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAFFJREFUeNpi/P//PwMFgBGo/+W0UvI0i2d1MzFQBijVz4JHjtfMAcL4fOoAOfq5TLwJ6h9o/w/m8P92ZitF+vEE+2j6GSbhT6l+RgrLP4AAAwB9eCIjar5kTwAAAABJRU5ErkJggg==">
        <p style="margin:0 auto; font-size:12px; font-weight:bold;">{!! $alarmsack !!}</p>
    </li>
    <li>
        <img style="margin: 0 2px 2px; width:20px; height:20px; border:none;"
            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABUAAAAVCAIAAAAmdTLBAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAUBJREFUeNpi+k8ZYGFgYHh/npGBLCBo+J+JgTIw0PpZ4CxGJiFWDjcg4/ePXf//vQMymFkNmVnV//6++ff3eawKUOwHynGrLwciiCIg4BQtAnKBJC4FKPp/fVvB8OczyEk8NlANAk5wEiH+5zNIJVb///1yBqSOWwtEcngwsEuBRNmlQGyYOEQNdv2/3u8CeZtTHWQttz3Ca2A2RByiBrv+3193QiwEBhWbSCBcHMgGikCcA1WD3f2/z//7dhOkgSeciQtk29+3m0CKuNSBIkAGUBYSFzjj/+/n00CSQzIfxPn57NMjfyAJF4HI4tP/68NWiIUgp37YBychIhBZvPphsQgE31/3wUnMmMOZfiExBPcqPFDQYg49/cLBj5ezWL5e+/PlCFzk++MGYOJBFkGkemAZMJTzPwvEGWTrBwgwAAmf0TPW0C5TAAAAAElFTkSuQmCC">
        <p style="margin:0 auto; font-size:12px; font-weight:bold;">{!! $warnings !!}</p>
    </li>
    <li>
        <img style="margin: 0 2px 2px; width:20px; height:20px; border:none;"
            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABUAAAAVCAIAAAAmdTLBAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAKtJREFUeNpi/P//PwMFgAWI389kJU+zYPpvJgbKAKX6WTCF+H33Qxhfjzf+eXMAqwg+/UxSNlAGGz8uEaq5f1Q/KeDv54ck6Gdk4wXFsIgDkv4LhNPPvzeXmUR0gQwuhwkcb5OZhHXh4kS5/+vBIoafH0Esdn5QymEHp5mfH0HixKRfYAr9tNaFUz2MWdIS6uznx7/fXIXpeOz6If78cubCSEg/jBSWfwABBgAbjD9+mVhlXQAAAABJRU5ErkJggg==">
        <p style="margin:0 auto; font-size:12px; font-weight:bold;">{!! $unusuals !!}</p>
    </li>
    <li>
        <img style="margin: 0 2px 2px; width:20px; height:20px; border: 1px solid #fff;"
            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABUAAAAVCAIAAAAmdTLBAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAPNJREFUeNpi/P//PwMFgBGof+Y+OTJ0inObBZivYSLPWqBmH6P5QAYT2Zq//HhBjn64zbsuZwFJFjI0s7Dy7r9Y9P7HTdLsh2u+8XD5rbdrIIJMpGp+9e7cwbvlcHEmkjT/+f15+5VUZCkm4jUD2bsvFfz485qAfh2xRHf1aYIc6miaz9zsffRxN5pi7OGvIO0DRECvCvGqQjQ/eXng7NOJmCqx2H/l1fyjV+qBDDEhI4jmr9+f7b1ZjNUm7P6HGwEEwDDbfSkPzduEww9uxMmbPS+/nsKlDF/6Axrx+uRVPJoJxx9+zWTmv8Gkn5HC8g8gwABYVW+W51R+EAAAAABJRU5ErkJggg==">
        <p style="margin:0 auto; font-size:12px; font-weight:bold;">{!! $ups !!}</p>
    </li>
</ul>
