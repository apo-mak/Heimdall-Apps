<?php namespace App\SupportedApps\NetworkUPSTools;

class NetworkUPSTools extends \App\SupportedApps {

}