<?php

namespace App\SupportedApps\Frigate;

class Frigate extends \App\SupportedApps
{
}
