<?php

namespace App\SupportedApps\Slskd;

class Slskd extends \App\SupportedApps
{
}
