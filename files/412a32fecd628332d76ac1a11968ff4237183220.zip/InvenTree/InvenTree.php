<?php namespace App\SupportedApps\InvenTree;

class InvenTree extends \App\SupportedApps {

}