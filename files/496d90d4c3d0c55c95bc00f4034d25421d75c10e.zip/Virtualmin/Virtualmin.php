<?php namespace App\SupportedApps\Virtualmin;

class Virtualmin extends \App\SupportedApps
{
}
