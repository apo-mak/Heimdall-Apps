<ul class="livestats">
    <li>
        <span class="title">Stream Count</span>
        <strong>{!! $stream_count !!}</strong>
    </li>
</ul>
