<?php

namespace App\SupportedApps\Grafana;

class Grafana extends \App\SupportedApps
{
}
