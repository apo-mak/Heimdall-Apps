<ul class="livestats">
    <li>
        <span class="title">Applications</span>
        <strong>{!! $applications !!}</strong>
    </li>
    <li>
        <span class="title">Users</span>
        <strong>{!! $users !!}</strong>
    </li>
</ul>
