<?php namespace App\SupportedApps\CalibreWeb;

class CalibreWeb extends \App\SupportedApps
{
}
