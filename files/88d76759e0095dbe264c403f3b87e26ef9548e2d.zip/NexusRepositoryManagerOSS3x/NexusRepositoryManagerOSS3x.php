<?php namespace App\SupportedApps\NexusRepositoryManagerOSS3x;

class NexusRepositoryManagerOSS3x extends \App\SupportedApps {

}
