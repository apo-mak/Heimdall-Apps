<?php namespace App\SupportedApps\Mailhog;

class Mailhog extends \App\SupportedApps
{
}
