<?php

namespace App\SupportedApps\Checkmk;

class Checkmk extends \App\SupportedApps
{
}
