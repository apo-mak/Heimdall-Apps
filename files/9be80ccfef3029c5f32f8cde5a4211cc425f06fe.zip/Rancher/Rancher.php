<?php

namespace App\SupportedApps\Rancher;

class Rancher extends \App\SupportedApps
{
}
