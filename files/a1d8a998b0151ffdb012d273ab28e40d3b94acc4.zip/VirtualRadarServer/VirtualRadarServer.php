<?php

namespace App\SupportedApps\VirtualRadarServer;

class VirtualRadarServer extends \App\SupportedApps
{
}
