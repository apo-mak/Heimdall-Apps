<?php

namespace App\SupportedApps\Pleroma;

class Pleroma extends \App\SupportedApps
{
}
