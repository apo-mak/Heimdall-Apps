<?php

namespace App\SupportedApps\osTicket;

class osTicket extends \App\SupportedApps // phpcs:ignore
{
}
