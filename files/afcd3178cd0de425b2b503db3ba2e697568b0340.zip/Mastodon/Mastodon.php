<?php

namespace App\SupportedApps\Mastodon;

class Mastodon extends \App\SupportedApps
{
}
