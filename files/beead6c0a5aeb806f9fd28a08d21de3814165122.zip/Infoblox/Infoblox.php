<?php namespace App\SupportedApps\Infoblox;

class Infoblox extends \App\SupportedApps
{
}
