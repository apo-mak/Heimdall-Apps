<ul class="livestats">
    <li>
        <span class="title">PAC</span>
        <strong>{{ $PAC }}{{ $PAC_UNIT }}</strong>
    </li>
    <li class="right">
        <span class="title">Day energy</span>
        <strong>{{ $DAY_ENERGY }}{{ $DAY_ENERGY_UNIT }}</strong>
    </li>
</ul>
