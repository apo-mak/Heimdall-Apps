<?php

namespace App\SupportedApps\SynologyPhoto;

class SynologyPhoto extends \App\SupportedApps
{
}
