<?php namespace App\SupportedApps\Robonect;

class Robonect extends \App\SupportedApps {

}