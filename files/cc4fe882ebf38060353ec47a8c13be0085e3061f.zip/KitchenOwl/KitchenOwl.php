<?php

namespace App\SupportedApps\KitchenOwl;

class KitchenOwl extends \App\SupportedApps
{
}
