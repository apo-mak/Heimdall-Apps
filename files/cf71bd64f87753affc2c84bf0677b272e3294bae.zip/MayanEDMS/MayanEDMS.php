<?php

namespace App\SupportedApps\MayanEDMS;

class MayanEDMS extends \App\SupportedApps
{
}
