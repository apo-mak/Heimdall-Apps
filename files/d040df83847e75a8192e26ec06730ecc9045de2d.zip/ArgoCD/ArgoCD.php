<?php namespace App\SupportedApps\ArgoCD;

class ArgoCD extends \App\SupportedApps
{
}
