<?php namespace App\SupportedApps\WindowsAdminCenter;

class WindowsAdminCenter extends \App\SupportedApps
{
}
