<?php

namespace App\SupportedApps\Wallabag;

class Wallabag extends \App\SupportedApps
{
}
