<ul class="livestats">
    <li>
        <span class="title">Warning</span>
        <strong>{!! $count_warning !!}</strong>
    </li>
    <li>
        <span class="title">Critical</span>
        <strong>{!! $count_critical !!}</strong>
    </li>
</ul>
