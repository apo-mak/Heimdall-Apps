<ul class="livestats">
    <li>
        <span class="title">Lessons</span>
        <strong>{!! $lessons !!}</strong>
    </li>
    <li>
        <span class="title">Reviews</span>
        <strong>{!! $reviews !!}</strong>
    </li>
</ul>
