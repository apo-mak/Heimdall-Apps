<?php namespace App\SupportedApps\NetgearOrbi;

class NetgearOrbi extends \App\SupportedApps
{
}
