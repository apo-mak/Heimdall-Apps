<?php

namespace App\SupportedApps\StirlingPDF;

class StirlingPDF extends \App\SupportedApps
{
}
