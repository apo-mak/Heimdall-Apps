<?php namespace App\SupportedApps\Sickchill;

class Sickchill extends \App\SupportedApps
{
}
